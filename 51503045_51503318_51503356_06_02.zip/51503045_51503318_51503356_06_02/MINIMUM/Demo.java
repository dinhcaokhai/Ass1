public class Demo{
		public static void main(String[] args){
			
		KruskalMST t = new KruskalMST();
			t.kruskalMST();
  
	}
}